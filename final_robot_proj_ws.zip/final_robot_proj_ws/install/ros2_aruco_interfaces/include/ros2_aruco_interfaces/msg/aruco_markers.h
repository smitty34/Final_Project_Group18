// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros2_aruco_interfaces:msg/ArucoMarkers.idl
// generated code does not contain a copyright notice

#ifndef ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_H_
#define ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_H_

#include "ros2_aruco_interfaces/msg/detail/aruco_markers__struct.h"
#include "ros2_aruco_interfaces/msg/detail/aruco_markers__functions.h"
#include "ros2_aruco_interfaces/msg/detail/aruco_markers__type_support.h"

#endif  // ROS2_ARUCO_INTERFACES__MSG__ARUCO_MARKERS_H_
